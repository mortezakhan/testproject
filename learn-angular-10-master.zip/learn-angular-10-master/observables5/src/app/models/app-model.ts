export interface User {
    name: string;
    age: number;
    status: string;
}