export interface user {
    email: string;
    password: string;
    address: string;
}