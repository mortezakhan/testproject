import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switchcase2',
  templateUrl: './switchcase2.component.html',
  styleUrls: ['./switchcase2.component.css']
})
export class Switchcase2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
