import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switchcase1',
  templateUrl: './switchcase1.component.html',
  styleUrls: ['./switchcase1.component.css']
})
export class Switchcase1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
