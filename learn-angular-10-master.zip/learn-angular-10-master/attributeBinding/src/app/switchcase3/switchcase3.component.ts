import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switchcase3',
  templateUrl: './switchcase3.component.html',
  styleUrls: ['./switchcase3.component.css']
})
export class Switchcase3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
