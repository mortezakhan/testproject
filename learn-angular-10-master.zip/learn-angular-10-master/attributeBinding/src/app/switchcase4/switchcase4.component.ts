import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switchcase4',
  templateUrl: './switchcase4.component.html',
  styleUrls: ['./switchcase4.component.css']
})
export class Switchcase4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
